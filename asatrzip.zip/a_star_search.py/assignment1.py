# A* Search Algorithm Implementation in Python

import heapq

def a_star_search(graph, start, goal, heuristic):

    # Priority queue to store nodes to explore
    open_list = []
    heapq.heappush(open_list, (0, start))  # (priority, node)

    # To track the cost of the shortest path from start to a node
    g_cost = {start: 0}

    # To reconstruct the path from start to goal
    prev = {}

    # Closed list to track visited nodes
    closed_list = set()

    while open_list:
        # Find the node with the least f on the open list
        current_priority, current_node = heapq.heappop(open_list)

        # If the goal is reached, reconstruct the path
        if current_node == goal:
            path = []
            while current_node in prev:
                path.append(current_node)
                current_node = prev[current_node]
            path.append(start)
            return path[::-1]  # Return the reversed path

        # Add the current node to the closed list
        closed_list.add(current_node)

        # Generate successors
        for neighbor, cost in graph[current_node].items():
            if neighbor in closed_list:
                continue

            # Calculate g, h, and f values for the neighbor
            tentative_g_cost = g_cost[current_node] + cost

            if neighbor not in g_cost or tentative_g_cost < g_cost[neighbor]:
                g_cost[neighbor] = tentative_g_cost
                f_cost = tentative_g_cost + heuristic(neighbor, goal)
                heapq.heappush(open_list, (f_cost, neighbor))
                prev[neighbor] = current_node

    return None  # Return None if no path is found

if __name__ == "__main__":
    # Example graph as an adjacency list (node: {neighbor: cost})
    graph = {
        'A': {'B': 1, 'C': 4},
        'B': {'A': 1, 'D': 2, 'E': 5},
        'C': {'A': 4, 'F': 3},
        'D': {'B': 2, 'E': 1},
        'E': {'B': 5, 'D': 1, 'F': 2},
        'F': {'C': 3, 'E': 2}
    }

    # Heuristic function (e.g., straight-line distance)
    def heuristic(node, goal):
        h = {
            'A': 7,
            'B': 6,
            'C': 2,
            'D': 1,
            'E': 0,
            'F': 3
        }
        return h.get(node, float('inf'))

    # Run the A* algorithm
    start_node = 'A'
    goal_node = 'D'
    path = a_star_search(graph, start_node, goal_node, heuristic)

    if path:
        print("Shortest path:", path)
    else:
        print("No path found")
